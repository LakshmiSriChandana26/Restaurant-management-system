from django.shortcuts import render, HttpResponse


# Create your views here.



def user_registration(request):
    print(request)
    return render(request, 'registration1.html')
