from enum import Enum

from django.db import models


class Item(models.Model):
    quantity: models.IntegerField()
    price: models.FloatField()
# Create your models here.


class LoginUser(models.Model):
    username: models.CharField(max_length=100)
    password: models.CharField(max_length=100)


class Gender(Enum):
    male = "Male"
    female = "Female"


class RegistrationData(models.Model):
    customername: models.CharField(max_length=100)
    mobilenumber: models.CharField(max_length=100)
    password: models.CharField(max_length=100)
    date_of_booking: models.DateField()
    gender: models.CharField(choices=Gender)
    vegetarian: models.BooleanField(default=False)
    message: models.CharField(max_length=100, null=True)
